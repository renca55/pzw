from django.contrib import admin
from pzwebapp.models import Language, User, Exchange

admin.site.register(Language)
admin.site.register(User)
admin.site.register(Exchange)
